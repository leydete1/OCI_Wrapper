
/*
 * OCI_Update_Execute_Module.c
 *
 * Stage 3 - Update Execute Module
 * --------------------------------
 * Executes a bulk UPDATE from an already-validated update_request_t
 * (built by Level 1). Mirrors OCI_Insert_Execute_Module in structure
 * and conventions.
 *
 * level2_validate_update() is called internally as this function's own
 * first step, not just trusted to have already run in the caller -
 * same reasoning as execute_insert_batch(), see its own doc comment in
 * OCI_Insert_Execute_Module.h.
 *
 * Key differences from insert:
 *   - update_request_t.keys[] (where_key_t) identifies rows to update;
 *     update_request_t.fields[] (field_value_t) is the SET clause - no
 *     per-row concept, unlike INSERT's rows[].
 *   - SQL: UPDATE owner.table SET col=:1,... WHERE key=:N,...
 *   - BLOB/CLOB in SET: same EMPTY_BLOB()/EMPTY_CLOB() +
 *     SELECT FOR UPDATE pattern as insert.
 *   - WHERE key columns always bind as SQLT_STR scalars.
 *
 * Reuses:
 *   - OCI_Insert_Validate_Module  (validate_field() - same type rules)
 *   - OCI_Table_Metadata_Module   (metadata_cache_get_or_fetch)
 *   - handle_blob_update / handle_clob_update (identical logic to
 *     insert counterparts, renamed for clarity)
 */

#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <time.h>

#include "Connection.h"
#include "Table_Metadata_Module.h"
#include "metadata_cache.h"
#include "metadata_cache_meta.h"


#include "Update_Execute_Module.h"
#include "Insert_Validate_Module.h"
#include "Level2_Parser.h"          /* level2_validate_update()      */
#include "Response_Writer.h"        /* response_write_dml_xml/json() */
#include <Audit_Trail_Manager.h>
#include "XML_Helper.h"
#include "db_type_class.h"   /* db_type_lob_kind() - Stage 4b */
#include "lob_text_bind.h"   /* lob_text_resolve() - driver_mssql Stage 4 */
#include "logger.h"
#include "metrics.h"
#include "metrics_writer.h"   /* metrics_finalise_and_enqueue() - closure item 5, Stage 2 */
#include "resultset_cache.h"  /* resultset_cache_invalidate_by_table() - closure item 5 follow-up, 2026-08-12 */
#include "Transaction_Manager.h"
#include "db_driver.h"        /* v2 driver integration, 2026-09-19 -
                                  dml_execute_returning_rowids()/
                                  rowid_result_free()/lob_write_by_rowid() -
                                  core calls only the vendor-neutral
                                  db_driver_get(), never driver_oracle.h
                                  directly, same as SELECT/DELETE's own
                                  integrations.                        */

/* Bug fix (2026-08-25/27) - moved to file scope from inside
 * execute_update_batch() itself, since the dynamic ROWID collector
 * helpers below (added 2026-08-27) also need it, and they're defined
 * ahead of that function in this file. Oracle's extended ROWID format
 * is always exactly 18 characters; 24 leaves a safety margin. */
#define ROWID_BUF_SIZE 24

/* ------------------------------------------------------------------ */
/*  Internal limits                                                     */
/* ------------------------------------------------------------------ */
#define MAX_UPD_COLS         1024
#define MAX_UPD_ROWS         5000
#define MAX_UPD_KEY_COLS     32
#define MAX_COL_VALUE_SIZE   32768
#define CLOB_FILE_PREFIX     "file://"
#define CLOB_FILE_PREFIX_LEN 7

/* ------------------------------------------------------------------ */
/*  Per-field value                                                     */
/*  large_value mirrors field_value_t's own overflow handling in         */
/*  OCI_Request_Response_Types.h, one layer down - only the CLOB SET     */
/*  write path (handle_clob_update) can ever need this; scalar columns   */
/*  are already bounded by their real Oracle column length via           */
/*  level2_validate_update(), and BLOB values arrive as a file path      */
/*  string, never inline content, so neither can realistically exceed    */
/*  MAX_COL_VALUE_SIZE. See upd_field_value_get() below.                  */
/* ------------------------------------------------------------------ */
typedef struct {
    char  value[MAX_COL_VALUE_SIZE];
    char *large_value;
    int   is_empty;
} upd_field_value_t;

/* Real value for one upd_field_value_t - see its own large_value        */
/* comment above.                                                        */
static const char *upd_field_value_get(const upd_field_value_t *v)
{
    return v->large_value ? v->large_value : v->value;
}

/* ------------------------------------------------------------------ */
/*  Parsed WHERE key field                                              */
/* ------------------------------------------------------------------ */
typedef struct {
    char field_name[128];
    char field_type[128];
    char key_value [MAX_COL_VALUE_SIZE];
} upd_key_field_t;

/* ------------------------------------------------------------------ */
/*  Parsed update context                                               */
/* ------------------------------------------------------------------ */
typedef struct {
    int               col_count;
    int               row_count;
    int               key_count;
    char              table_name[128];
    char              owner     [128];
    char              col_names [MAX_UPD_COLS][128];
    upd_field_value_t *values;       /* [row * MAX_UPD_COLS + col]    */
    upd_key_field_t   keys[MAX_UPD_KEY_COLS];
} update_ctx_t;

/* Frees every entry's large_value (a calloc'd array's untouched
 * entries are already NULL - safe no-ops) before the caller frees
 * values itself - same reasoning as free_insert_ctx_values() in
 * OCI_Insert_Execute_Module.c.                                        */
static void free_update_ctx_values(upd_field_value_t *values, int count)
{
    if (!values) return;
    for (int i = 0; i < count; i++)
        free(values[i].large_value);
    free(values);
}

/* ------------------------------------------------------------------ */
/*  build_update_ctx_from_request                                       */
/*  Populates update_ctx_t directly from an already-parsed               */
/*  update_request_t - replaces the old parse_update_xml(); no XML       */
/*  parsing happens in this file at all any more.                        */
/*                                                                         */
/*  Always exactly one logical "row" of SET values (uc->row_count = 1) -  */
/*  matches the old XML template's own convention (borrowed from          */
/*  INSERT's per-row shape, but an UPDATE only ever has one flat SET      */
/*  list applied to however many rows the WHERE clause matches at         */
/*  execute time - see update_request_t's own doc comment in              */
/*  OCI_Update_Execute_Module.h).                                         */
/* ------------------------------------------------------------------ */
static int build_update_ctx_from_request(oci_context_t          *ctx,
                                          const update_request_t *req,
                                          update_ctx_t           *uc)
{
    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Entering build_update_ctx_from_request");

    memset(uc, 0, sizeof(*uc));

    strncpy(uc->table_name, req->table_name, sizeof(uc->table_name) - 1);
    strncpy(uc->owner,      req->owner,      sizeof(uc->owner) - 1);

    /* ---- WHERE keys ---- */
    if (req->key_count <= 0 || req->key_count > MAX_UPD_KEY_COLS)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "key_count=%d out of range (1..%d) - "
                     "level2_validate_update() should have caught this",
                     req->key_count, MAX_UPD_KEY_COLS);
        return -1;
    }
    uc->key_count = req->key_count;
    for (int k = 0; k < req->key_count; k++)
    {
        strncpy(uc->keys[k].field_name, req->keys[k].field_name,
                sizeof(uc->keys[k].field_name) - 1);
        strncpy(uc->keys[k].key_value, req->keys[k].key_value,
                sizeof(uc->keys[k].key_value) - 1);
        /* field_type left empty - build_update_sql() resolves the real
         * type itself from cols[] metadata, not from this struct.      */
    }

    /* ---- SET fields - always exactly one logical row (see this
     * function's own doc comment).                                     */
    if (req->field_count <= 0 || req->field_count > MAX_UPD_COLS)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "field_count=%d out of range (1..%d) - "
                     "level2_validate_update() should have caught this",
                     req->field_count, MAX_UPD_COLS);
        return -1;
    }
    uc->col_count = req->field_count;
    uc->row_count = 1;

    for (int c = 0; c < req->field_count; c++)
        strncpy(uc->col_names[c], req->fields[c].field_name,
                sizeof(uc->col_names[c]) - 1);

    uc->values = calloc((size_t)uc->col_count, sizeof(upd_field_value_t));
    if (!uc->values)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "calloc failed for values array (%d cols x %zu bytes)",
                     uc->col_count, sizeof(upd_field_value_t));
        return -1;
    }

    for (int c = 0; c < req->field_count; c++)
    {
        const char *real_value = field_value_get(&req->fields[c]);
        size_t      real_len   = strlen(real_value);

        upd_field_value_t *dest = &uc->values[c];

        if (real_len < sizeof(dest->value))
        {
            strncpy(dest->value, real_value, sizeof(dest->value) - 1);
            dest->large_value = NULL;
        }
        else
        {
            /* Doesn't fit even MAX_COL_VALUE_SIZE - mirror
             * field_value_t's own overflow handling. See
             * upd_field_value_t's doc comment.                         */
            dest->large_value = malloc(real_len + 1);
            if (dest->large_value)
                memcpy(dest->large_value, real_value, real_len + 1);
            strncpy(dest->value, real_value, sizeof(dest->value) - 1);
            dest->value[sizeof(dest->value) - 1] = '\0';
        }
        dest->is_empty = (real_len == 0);
    }

    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "build_update_ctx_from_request OK: keys=%d cols=%d "
                 "allocated=%zu bytes",
                 uc->key_count, uc->col_count,
                 (size_t)uc->col_count * sizeof(upd_field_value_t));
    return 0;
}


/* get_upd_bind_wrapper() was removed here (Oracle dialect extraction,
 * Stage 2, 2026-10-02) - see build_update_sql() below and db_dialect_t
 * in db_driver.h. Same output, now from the driver's value_expr()/
 * lob_placeholder(). */

/* ================================================================== */
/*  build_update_sql                                                    */
/*  UPDATE owner.table                                                  */
/*  SET col1=:1, col2=EMPTY_BLOB(), ...                                */
/*  WHERE key1=:N, key2=:N+1, ...                                      */
/* ================================================================== */
static int build_update_sql(oci_context_t        *ctx,
                              const update_ctx_t   *uc,
                              const col_metadata_t *cols,
                              int                   col_meta_count,
                              char                 *sql_buf,
                              size_t                sql_max,
                              int                  *out_bind_num)
{
    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Building UPDATE SQL table='%s'", uc->table_name);

    char set_list [MAX_UPD_COLS * 256] = {0};
    int  bind_pos = 1;

    /* Stage 2 - every vendor fragment comes from the driver. */
    const db_dialect_t *dl = db_driver_get(ctx)->dialect;

    /* ---- SET clause ---- */
    for (int i = 0; i < uc->col_count; i++)
    {
        if (i > 0)
            strncat(set_list, ", ",
                    sizeof(set_list) - strlen(set_list) - 1);

        /* Find type. Stage 4b: fallback "" - see build_insert_sql()'s
         * note; the dialect output is the same as for "VARCHAR2". */
        const char *dtype = "";
        for (int m = 0; m < col_meta_count; m++)
            if (strcasecmp(cols[m].col_name, uc->col_names[i]) == 0)
            { dtype = cols[m].data_type; break; }

        char assignment[512] = {0};
        const char *lob_literal = dl->lob_placeholder(dtype);

        if (lob_literal)
        {
            /* LOB: the driver's placeholder literal, no bind position */
            snprintf(assignment, sizeof(assignment),
                     "%s=%s", uc->col_names[i], lob_literal);
        }
        else
        {
            char bind_ph[32];
            char expr[256];
            if (dl->bind_placeholder(bind_pos++, bind_ph, sizeof(bind_ph)) != 0 ||
                dl->value_expr(dtype, bind_ph, expr, sizeof(expr)) != 0)
            {
                logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                             "dialect could not build the bind expression "
                             "for SET column '%s' type '%s'",
                             uc->col_names[i], dtype);
                return -1;
            }
            snprintf(assignment, sizeof(assignment),
                     "%s=%s", uc->col_names[i], expr);
        }

        strncat(set_list, assignment,
                sizeof(set_list) - strlen(set_list) - 1);
    }

    /* ---- WHERE clause ---- */
    char where_list[MAX_UPD_KEY_COLS * 256] = {0};

    for (int k = 0; k < uc->key_count; k++)
    {
        if (k > 0)
            strncat(where_list, " AND ",
                    sizeof(where_list) - strlen(where_list) - 1);

        char bind_ph[32];
        if (dl->bind_placeholder(bind_pos++, bind_ph, sizeof(bind_ph)) != 0)
        {
            logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                         "dialect could not build a bind placeholder");
            return -1;
        }

        /* Apply date/timestamp/interval wrapper to WHERE keys too if
         * needed - resolved from cols[] by real column name lookup,
         * same as the SET clause above. Found and fixed 2026-07-26:
         * this used to read uc->keys[k].field_type directly, a field
         * build_update_ctx_from_request() deliberately leaves empty -
         * see that function's own comment - meaning this comparison
         * could never match and the wrapper was silently never applied
         * for any WHERE key, ever. Isolated to just this one section;
         * the SET clause loop above it, and every other type
         * resolution in this project, already does the real lookup.  */
        const char *ktype = "";
        for (int m = 0; m < col_meta_count; m++)
            if (strcasecmp(cols[m].col_name, uc->keys[k].field_name) == 0)
            { ktype = cols[m].data_type; break; }

        /* Stage 2: value_expr() is the driver's conversion. WHERE keys
         * never take a LOB placeholder - a LOB can't be compared with =
         * (before Stage 2 a LOB-typed key would have produced
         * "key=EMPTY_BLOB()", which Oracle rejects; now it is
         * "key=:n", which Oracle rejects too - no fixture does this). */
        char expr[256];
        if (dl->value_expr(ktype, bind_ph, expr, sizeof(expr)) != 0)
        {
            logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                         "dialect could not build the bind expression "
                         "for WHERE key '%s' type '%s'",
                         uc->keys[k].field_name, ktype);
            return -1;
        }

        char cond[512] = {0};
        snprintf(cond, sizeof(cond),
                 "%s=%s", uc->keys[k].field_name, expr);

        strncat(where_list, cond,
                sizeof(where_list) - strlen(where_list) - 1);
    }

    /* ---- Assemble ---- */
    int n;
    /* Bug fix (2026-08-25) - RETURNING ROWID INTO, same fix as
     * execute_insert_batch()'s own (see build_insert_sql()'s doc
     * comment for the full rationale - OCI_ATTR_ROWID unreliable for
     * multi-row statements, and the old code only ever wrote row_base's
     * LOB content regardless of how many rows the UPDATE actually
     * matched). One difference from the INSERT side worth noting:
     * bind_pos here is POST-incremented throughout the SET and WHERE
     * loops above (used, then incremented) - so its final value is
     * ALREADY the next available bind position, unlike build_insert_
     * sql()'s bind_num which needed +1. Using bind_pos directly here. */
    int rowid_bind_pos = bind_pos;

    /* Stage 2 - the row locator is the driver's (Oracle: nothing in the
     * middle, "RETURNING ROWID INTO :n" at the end). */
    char loc_mid[512]  = {0};
    char loc_tail[512] = {0};
    /* driver_mssql Stage 4 (U1): the driver names the column its row
     * locator returns (SQL Server: OUTPUT inserted.<key>). Oracle has
     * no table_key hook result - ROWID needs no column - so its SQL is
     * unchanged. */
    char        loc_key[128]  = {0};
    const char *loc_keys[1]   = { loc_key };
    int         loc_key_count = 0;
    const db_driver_t *loc_drv = db_driver_get(ctx);
    if (loc_drv->table_key &&
        loc_drv->table_key(ctx, uc->owner, uc->table_name,
                           loc_key, sizeof(loc_key), &loc_key_count) != 0)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "driver could not look up the row key of '%s'",
                     uc->table_name);
        return -1;
    }
    db_row_locator_ctx_t loc = { uc->table_name, uc->owner,
                                 loc_key_count ? loc_keys : NULL,
                                 loc_key_count };
    if (dl->row_locator_clauses(DB_DML_UPDATE, &loc, rowid_bind_pos,
                                loc_mid, sizeof(loc_mid),
                                loc_tail, sizeof(loc_tail)) != 0)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "dialect could not build the row locator clauses");
        return -1;
    }

    if (strlen(uc->owner) > 0)
        n = snprintf(sql_buf, sql_max,
                     "UPDATE %s.%s SET %s%s%s WHERE %s%s%s",
                     uc->owner, uc->table_name, set_list,
                     loc_mid[0] ? " " : "", loc_mid,
                     where_list,
                     loc_tail[0] ? " " : "", loc_tail);
    else
        n = snprintf(sql_buf, sql_max,
                     "UPDATE %s SET %s%s%s WHERE %s%s%s",
                     uc->table_name, set_list,
                     loc_mid[0] ? " " : "", loc_mid,
                     where_list,
                     loc_tail[0] ? " " : "", loc_tail);

    if (n < 0 || (size_t)n >= sql_max)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "UPDATE SQL truncated - increase sql_buf size");
        return -1;
    }

    if (out_bind_num) *out_bind_num = rowid_bind_pos;

    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "UPDATE SQL: %s", sql_buf);
    return 0;
}


/* ================================================================== */
/*  handle_blob_update() / handle_clob_update() / dynamic_rowid_       */
/*  collector_t (init/free/rowid_in_callback/rowid_out_callback) were  */
/*  removed here (Phase 2, 2026-09-19) - no remaining caller anywhere  */
/*  in this file once the driver integration landed.                  */
/*                                                                      */
/*  execute_update_batch() now fetches through                        */
/*  driver->dml_execute_returning_rowids()/lob_write_by_rowid() (see   */
/*  the v2 driver integration comment inside execute_update_batch()    */
/*  itself), which do their own self-contained RETURNING ROWID         */
/*  collection and LOB writing (driver_oracle.c's own                  */
/*  oracle_dml_execute_returning_rowids()/oracle_lob_write_by_rowid(),  */
/*  themselves faithful ports of exactly these functions - see that    */
/*  file's own comments) and never touch a core-owned collector or     */
/*  bind-structure array.                                              */
/* ================================================================== */


int execute_update_batch(oci_context_t     *ctx,
                          update_request_t  *req,
                          execute_config_t  *cfg)
{
    int            rc           = 0;
    xml_builder_t *xml          = NULL;
    update_ctx_t  *uc           = NULL;
    const char   **bind_values  = NULL;   /* built fresh in Stage 3, not
                                              inherited from the old
                                              bind_hdls/scalar_bufs/
                                              indicators trio - see that
                                              stage's own comment       */

    int            rows_updated = 0;
    int            lob_count    = 0;
    uint64_t       lob_bytes    = 0;   /* total BLOB bytes written    */
    uint64_t       clob_bytes   = 0;   /* total CLOB bytes written    */
    struct timespec ts_start, ts_end;
    audit_old_value_t *old_values    = NULL;  /* before-image for audit */
    char             **text_heap       = NULL; /* driver_mssql Stage 4 (U6) */
    int                text_heap_count = 0;
    int                text_bound_cols = 0;
    uint64_t           text_bound_bytes = 0;
    int                old_row_count = 0;

    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Entering execute_update_batch");

    if (!ctx || !req || !cfg)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "Invalid arguments");
        return -1;
    }

    /* Give this call its own transaction identity if it doesn't already
     * have one - fixes the 2026-07-26 GxP traceability gap. See
     * execute_insert_batch()'s identical fix and the full reasoning in
     * OCI_Transaction_Manager.h's own doc comment for these functions.
     * Particularly relevant here: this is exactly the call chain
     * (before-image SELECT -> AUDIT_TRAIL INSERT -> the UPDATE itself)
     * that first surfaced the gap, via session_end()'s standalone
     * calls.                                                            */
    tx_handle_t local_tx;
    int owns_standalone_tx = begin_standalone_tx_if_needed(ctx, &local_tx);


    metrics_record_t metrics;
     metrics_init(&metrics);
     metrics_set_context(&metrics, ctx);
     metrics.start_time_us = metrics_now_us();
     strncpy(metrics.operation, "UPDATE", sizeof(metrics.operation) - 1);

     /* Set transaction_id immediately so every write path carries it  */
            if (ctx->active_tx)
                strncpy(metrics.transaction_id,
                        tx_get_id(ctx->active_tx),
                        sizeof(metrics.transaction_id) - 1);
            else
                strncpy(metrics.transaction_id, "-",
                        sizeof(metrics.transaction_id) - 1);
            /* Same source as transaction_id above, just the name -
             * closure item 5 follow-up (2026-08-10).                  */
            strncpy(metrics.transaction_name,
                    ctx->active_tx ? ctx->active_tx->tx_name : "-",
                    sizeof(metrics.transaction_name) - 1);

    /* ================================================================
     *  Stage 1 - Validate
     *  Called internally rather than trusted to have already run in
     *  the caller - see this file's own top-of-file doc comment.
     * ================================================================ */
    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Stage 1: Validating request");

    input_c_operation_t validate_op;
    memset(&validate_op, 0, sizeof(validate_op));
    validate_op.type    = OP_UPDATE;
    validate_op.payload = (void *)req;

    operation_status_t val_status;
    memset(&val_status, 0, sizeof(val_status));

    if (level2_validate_update(ctx, &validate_op, &val_status) != LEVEL2_OK)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "Stage 1 validation failed: %s", val_status.error_text);
        return -1;
    }
    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Stage 1 validation passed");

    /* ================================================================
     *  Stage 2 - Build update context and prepare statement
     * ================================================================ */
    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Stage 2: Building update context and preparing statement");

    uc = calloc(1, sizeof(update_ctx_t));
    if (!uc)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "calloc failed for update_ctx_t");
        rc = -1;
        goto Cleanup;
    }

    if (build_update_ctx_from_request(ctx, req, uc) != 0)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "build_update_ctx_from_request failed");
        rc = -1;
        goto Cleanup;
    }
    strncpy(metrics.object_name, uc->table_name,
             sizeof(metrics.object_name) - 1);

    /* No row_count cap here any more - uc->row_count is always exactly
     * 1 for UPDATE now (one flat SET list; see build_update_ctx_from_
     * request()'s own doc comment), not a client-supplied number that
     * needs bounding the way INSERT's row_count does.                  */

    /* Load column metadata for type mapping */
    col_metadata_t     cols[MAX_UPD_COLS];
    int                col_meta_count = 0;
    metadata_request_t meta_req;

    memset(&meta_req, 0, sizeof(meta_req));
    strncpy(meta_req.table_name, uc->table_name,
            sizeof(meta_req.table_name) - 1);
    strncpy(meta_req.owner, uc->owner,
            sizeof(meta_req.owner) - 1);

    metadata_cache_result_t meta_result;
    memset(&meta_result, 0, sizeof(meta_result));

    if (metadata_cache_get_or_fetch(ctx->metadata_cache,
                                     ctx,
                                     &meta_req,
                                     cols,
                                     &col_meta_count,
                                     MAX_UPD_COLS,
                                     &meta_result) != 0)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "metadata_cache_get_or_fetch failed");
        rc = -1;
        goto Cleanup;
    }

    /* Wire metadata cache stats into metrics                          */
    metrics.cache_hit       = meta_result.was_cache_hit;
    metrics.cache_lookup_us = meta_result.cache_lookup_us;
    metrics.cache_key_hash  = meta_result.cache_key_hash;

    /* Build UPDATE SQL */
    char sql_buf[65536] = {0};
    int  rowid_bind_num = 0;
    if (build_update_sql(ctx, uc, cols, col_meta_count,
                          sql_buf, sizeof(sql_buf), &rowid_bind_num) != 0)
    {
        rc = -1;
        goto Cleanup;
    }

    /* sql_hash: hash the built SQL for traceability in metrics        */
    if (ctx->metadata_cache)
        metrics.sql_hash = cache_hash_string(ctx->metadata_cache, sql_buf);

    /* v2 driver integration (2026-09-19). The old, separate
     * OCIStmtPrepare2 call that used to sit here is gone -
     * dml_execute_returning_rowids() does prepare/bind/execute/collect/
     * release as one atomic call (see db_driver.h's own doc comment).
     * RETURNING ROWID INTO is unconditional in every UPDATE's SQL
     * (confirmed directly against build_update_sql() - not just when a
     * LOB column is present), so EVERY update, scalar-only or not, goes
     * through this one driver call - there is no separate "simple"
     * dml_execute() path for UPDATE the way there might first appear to
     * be from this module's own Path-A/Path-B-shaped history; only
     * whether the post-execute LOB-write loop below actually runs
     * varies.
     *
     * Core only ever calls the vendor-neutral db_driver_get() - never
     * reaches for driver_oracle.h directly, same reasoning as SELECT/
     * DELETE's own integrations. */
    const db_driver_t *driver = db_driver_get(ctx);
    if (!driver || !driver->dml_execute_returning_rowids ||
        !driver->rowid_result_free || !driver->lob_write_by_rowid ||
        !driver->commit || !driver->rollback)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "db_driver_get() returned an incomplete driver");
        rc = -1;
        goto Cleanup;
    }

    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "rows=%d cols=%d keys=%d",
                 uc->row_count, uc->col_count, uc->key_count);

    /* ================================================================
     *  Stage 3 - Build bind value array
     *  v2 driver integration: no more manual bind_hdls/scalar_bufs/
     *  indicators allocation here - dml_execute_returning_rowids()
     *  owns OCIBindByPos/OCIBindDynamic internally (driver_oracle.c).
     *  This stage now only needs to build the plain array of pointers
     *  it expects - SET values first (skipping LOB columns, which
     *  still use EMPTY_BLOB()/EMPTY_CLOB() literals with no bind
     *  placeholder at all - core, i.e. build_update_sql(), decides
     *  that, unchanged by this pass), then WHERE key values, in
     *  exactly the same position order build_update_sql() already
     *  wrote into the SQL text itself.
     *
     *  fv->is_empty (a genuinely NULL SET value) maps to a NULL entry
     *  in bind_values - see db_dml_returning_request_t's own doc
     *  comment in db_driver.h for what the driver does with that
     *  (binds real SQL NULL, not empty string - a real fix made
     *  2026-09-19 specifically because this exact case needed it).
     * ================================================================ */
    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Stage 3: Building bind value array");

    int total_bind_cols = uc->col_count + uc->key_count;
    bind_values = calloc((size_t)total_bind_cols, sizeof(char *));
    text_heap   = calloc((size_t)uc->col_count + 1, sizeof(char *));
    if (!bind_values || !text_heap)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "calloc failed for bind_values");
        rc = -1;
        goto Cleanup;
    }

    int scalar_bind_pos = 0;   /* 0-based array index - matches SQL's
                                   own 1-based :N positions offset by
                                   one, not a separate counter needing
                                   its own reasoning */

    for (int c = 0; c < uc->col_count; c++)
    {
        const char *dtype = "";
        for (int m = 0; m < col_meta_count; m++)
            if (strcasecmp(cols[m].col_name, uc->col_names[c]) == 0)
            { dtype = cols[m].data_type; break; }

        /* LOB: the dialect's LOB placeholder in SQL - no bind, skip.
         * Stage 4b: db_type_lob_kind() agrees with lob_placeholder(). */
        if (db_type_lob_kind(dtype) != DB_LOB_NONE)
            continue;

        const upd_field_value_t *fv = &uc->values[c];
        const char *bv = fv->is_empty ? NULL : upd_field_value_get(fv);

        /* driver_mssql Stage 4 (U6) - see execute_insert_batch(): a
         * text LOB bound in the statement takes a file:// value's
         * contents; counted per updated row below, as the CLOB write
         * further down counts it on Oracle. */
        if (!fv->is_empty && db_type_text_bound(dtype))
        {
            char  *heap = NULL;
            size_t tlen = 0;
            if (lob_text_resolve(upd_field_value_get(fv), &bv, &heap,
                                 &tlen, ctx->update_logger) != 0)
            {
                rc = -1;
                goto Cleanup;
            }
            if (heap) text_heap[text_heap_count++] = heap;
            text_bound_cols++;
            text_bound_bytes += tlen;
        }
        bind_values[scalar_bind_pos] = bv;

        logger_write(ctx->update_logger, LOG_DEBUG, __func__, 0,
                     "Bind SET col=%d name='%s' bind_pos=%d (%s)",
                     c, uc->col_names[c], scalar_bind_pos + 1,
                     fv->is_empty ? "SQL NULL" : "value");

        scalar_bind_pos++;
    }

    for (int k = 0; k < uc->key_count; k++)
    {
        bind_values[scalar_bind_pos + k] = uc->keys[k].key_value;

        logger_write(ctx->update_logger, LOG_DEBUG, __func__, 0,
                     "Bind WHERE key=%d name='%s' value='%s' bind_pos=%d",
                     k, uc->keys[k].field_name, uc->keys[k].key_value,
                     scalar_bind_pos + k + 1);
    }

    int total_scalar_binds = scalar_bind_pos + uc->key_count;

    /* ================================================================
     *  Stage 2 Audit - Fetch before-image BEFORE the UPDATE executes
     *
     *  We capture the current column values now, while they still hold
     *  the pre-update state.  The before-image is a SELECT on the same
     *  session and same transaction so it sees the consistent snapshot
     *  of the data as it exists before our UPDATE statement runs.
     *
     *  audit_trail_fetch_before_image() builds:
     *    SELECT col1, col2, ... FROM owner.table
     *    WHERE  key1 = 'val1' AND key2 = 'val2' ...
     *  and parses the result into old_values[row * col_count + col].
     *
     *  Key names/values come from uc->keys[] which was parsed from the
     *  <where> block of the Update_Template XML.
     * ================================================================ */
    if (!audit_trail_in_progress)
    {
        /* Build key name/value/type arrays from uc->keys[] */
        char (*key_names) [128]   = NULL;
        char (*key_vals)  [32768] = NULL;
        char (*key_types) [128]   = NULL;

        key_names = calloc((size_t)uc->key_count, sizeof(*key_names));
        key_vals  = calloc((size_t)uc->key_count, sizeof(*key_vals));
        key_types = calloc((size_t)uc->key_count, sizeof(*key_types));

        if (key_names && key_vals && key_types)
        {
            for (int k = 0; k < uc->key_count; k++)
            {
                strncpy(key_names[k], uc->keys[k].field_name,
                        sizeof(key_names[k]) - 1);
                strncpy(key_vals[k],  uc->keys[k].key_value,
                        sizeof(key_vals[k])  - 1);

                /* Real type from cols[] - never trust a client-
                 * supplied type (there isn't one here anyway; see the
                 * 2026-07-26 fix in OCI_Audit_Trail_Manager.c/.h for
                 * why this parameter exists at all now).               */
                /* Stage 4b: this fallback is left as "VARCHAR2" for
                 * now - it is handed to audit_trail_fetch_before_image()
                 * (Audit_Trail_Manager.c), which 4b does not cover.
                 * Never used in practice: Level 2 has already checked
                 * every WHERE key exists in cols[]. */
                strncpy(key_types[k], "VARCHAR2", sizeof(key_types[k]) - 1);
                for (int m = 0; m < col_meta_count; m++)
                    if (strcasecmp(cols[m].col_name, uc->keys[k].field_name) == 0)
                    {
                        strncpy(key_types[k], cols[m].data_type,
                                sizeof(key_types[k]) - 1);
                        break;
                    }
            }

            int fetch_rc =
                audit_trail_fetch_before_image(ctx,
                                               uc->table_name,
                                               uc->owner,
                                               uc->col_names,
                                               uc->col_count,
                                               key_names,
                                               key_vals,
                                               key_types,
                                               uc->key_count,
                                               &old_values,
                                               &old_row_count);
            if (fetch_rc != 0)
            {
                logger_write(ctx->update_logger, LOG_WARN, __func__, 0,
                             "Before-image fetch failed (rc=%d) for "
                             "table='%s' - UPDATE will proceed but "
                             "audit trail OLD_VALUE will be unavailable",
                             fetch_rc, uc->table_name);
                /* old_values remains NULL - audit will be skipped below */
            }
            else
            {
                logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                             "Before-image captured: %d row(s) "
                             "for table='%s'",
                             old_row_count, uc->table_name);
            }
        }

        free(key_names);
        free(key_vals);
        free(key_types);
    }

    /* ================================================================
     *  Stage 4 - Execute via the driver
     *  v2 integration: the old row_base/batch_rows while loop is gone -
     *  uc->row_count is unconditionally 1 (confirmed directly against
     *  build_update_ctx_from_request(), the only place it's ever
     *  assigned - one line, no conditional), so that loop only ever
     *  ran once; this is now a straight-line sequence matching what
     *  actually happens, not what the old per-row-VALUE-array bind
     *  shape (OCIBindArrayOfStruct, also gone - batch_rows>1 never
     *  happened either) made it look like it might.
     * ================================================================ */
    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Stage 4: Execute via driver");

    clock_gettime(CLOCK_MONOTONIC, &ts_start);

    db_dml_returning_request_t dml_req;
    memset(&dml_req, 0, sizeof(dml_req));
    dml_req.sql                     = sql_buf;
    dml_req.bind_count              = total_scalar_binds;
    dml_req.bind_values             = bind_values;
    dml_req.returning_bind_position = rowid_bind_num;

    db_rowid_result_t rowid_result;
    if (driver->dml_execute_returning_rowids(ctx, ctx->update_logger,
                                              &dml_req, &rowid_result) != 0)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "driver dml_execute_returning_rowids failed for sql=%s",
                     sql_buf);
        rc = -1;
        goto Cleanup;
    }

    metrics.execution_us += metrics_now_us() - metrics.start_time_us;

    /* Bug fix (2026-09-19, closing the gap found during this pass's own
     * analysis): rows_updated now reads rowid_result.count - the REAL
     * number of physical rows Oracle's own RETURNING clause reported -
     * not a bind-iteration count that was always 1 regardless of how
     * many rows genuinely matched (confirmed directly: WHERE
     * NUMBER_COL=300 matching 209 rows used to report rows_affected=1
     * in the response). The LOB-writing fix already used the right
     * count (rowid_collector.count, now rowid_result.count) for its own
     * purposes since 2026-08-27 - this brings the RESPONSE's own
     * rows_affected to the same correctness, not a new behavior being
     * invented. */
    rows_updated = rowid_result.count;
    metrics.rows_affected = (uint64_t)rows_updated;
    lob_count  += text_bound_cols * rows_updated;            /* Stage 4 (U6) */
    clob_bytes += text_bound_bytes * (uint64_t)rows_updated;

    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "driver dml_execute_returning_rowids OK rows_updated=%d",
                 rows_updated);

    /* ---- Post-execute: write LOB data ----
     * Same reasoning as the 2026-08-25/27 fix this replaces (preserved
     * in spirit below): the real bound for how many rows need LOB
     * content is rowid_result.count, not a fixed batch shape - and the
     * same one set of SET-clause values goes to every row Oracle
     * reports as affected, matching what a normal UPDATE...WHERE
     * genuinely does. */
    {
        int has_lob_column = 0;
        for (int bc = 0; bc < uc->col_count && !has_lob_column; bc++)
            for (int m = 0; m < col_meta_count; m++)
                if (strcasecmp(cols[m].col_name, uc->col_names[bc]) == 0 &&
                    db_type_lob_kind(cols[m].data_type) != DB_LOB_NONE)
                { has_lob_column = 1; break; }

        if (has_lob_column)
        {
            char tbl_fq[256] = {0};
            if (strlen(uc->owner) > 0)
                snprintf(tbl_fq, sizeof(tbl_fq), "%s.%s",
                         uc->owner, uc->table_name);
            else
                snprintf(tbl_fq, sizeof(tbl_fq), "%s", uc->table_name);

            logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                         "UPDATE affected %d row(s) - writing LOB "
                         "content to every one", rows_updated);

            /* Resolve each LOB column's value ONCE here, before the
             * per-row loop - not once per row, unlike the code this
             * replaces (handle_clob_update() used to re-open and
             * re-read the same file for every matched row; same
             * content, redundant work). A genuine small efficiency
             * improvement found while integrating, not just a refactor -
             * worth knowing about, not just silently changed. BLOB's
             * value is always a file path already (file_path field);
             * CLOB needs the same file://-prefix check
             * handle_clob_update() used to do internally, now done
             * once here instead. */
            for (int bc = 0; bc < uc->col_count; bc++)
            {
                const char *btype = "";
                for (int m = 0; m < col_meta_count; m++)
                    if (strcasecmp(cols[m].col_name, uc->col_names[bc]) == 0)
                    { btype = cols[m].data_type; break; }

                const upd_field_value_t *fv = &uc->values[bc];
                if (fv->is_empty) continue;

                db_lob_kind_t lob_kind = db_type_lob_kind(btype);
                int is_blob = (lob_kind == DB_LOB_BINARY);
                int is_clob = (lob_kind == DB_LOB_TEXT);
                if (!is_blob && !is_clob) continue;

                const char *resolved_text = NULL;
                size_t      resolved_len  = 0;
                int         text_is_heap  = 0;

                if (is_clob)
                {
                    const char *raw = upd_field_value_get(fv);
                    if (strncmp(raw, CLOB_FILE_PREFIX,
                                CLOB_FILE_PREFIX_LEN) == 0)
                    {
                        const char *file_path = raw + CLOB_FILE_PREFIX_LEN;
                        FILE *fp = fopen(file_path, "r");
                        if (!fp)
                        {
                            logger_write(ctx->update_logger, LOG_ERROR,
                                         __func__, 0,
                                         "Failed to open CLOB file: %s",
                                         file_path);
                            rc = -1;
                            driver->rowid_result_free(&rowid_result);
                            goto Cleanup;
                        }
                        fseek(fp, 0, SEEK_END);
                        long fsize = ftell(fp);
                        fseek(fp, 0, SEEK_SET);
                        char *buf = malloc((size_t)fsize + 1);
                        if (!buf)
                        {
                            fclose(fp);
                            rc = -1;
                            driver->rowid_result_free(&rowid_result);
                            goto Cleanup;
                        }
                        size_t nread = fread(buf, 1, (size_t)fsize, fp);
                        fclose(fp);
                        buf[nread] = '\0';
                        resolved_text = buf;
                        resolved_len  = nread;
                        text_is_heap  = 1;
                    }
                    else
                    {
                        resolved_text = raw;
                        resolved_len  = strlen(raw);
                    }
                }

                for (int r = 0; r < rowid_result.count; r++)
                {
                    const char *row_rowid = rowid_result.rowids +
                                             (size_t)r * ROWID_BUF_SIZE;

                    logger_write(ctx->update_logger, LOG_DEBUG, __func__, 0,
                                 "Writing %s col='%s' row r=%d ROWID='%s'",
                                 is_blob ? "BLOB" : "CLOB",
                                 uc->col_names[bc], r, row_rowid);

                    db_lob_write_request_t lob_req;
                    memset(&lob_req, 0, sizeof(lob_req));
                    lob_req.is_blob     = is_blob;
                    lob_req.table_fq    = tbl_fq;
                    lob_req.column_name = uc->col_names[bc];
                    lob_req.rowid_str   = row_rowid;

                    uint64_t bytes_written = 0;
                    int lob_rc;
                    if (is_blob)
                    {
                        lob_req.file_path = fv->value;
                        lob_rc = driver->lob_write_by_rowid(ctx, ctx->update_logger,
                                                             &lob_req, &bytes_written);
                        lob_bytes += bytes_written;
                    }
                    else
                    {
                        lob_req.inline_text     = resolved_text;
                        lob_req.inline_text_len = resolved_len;
                        lob_rc = driver->lob_write_by_rowid(ctx, ctx->update_logger,
                                                             &lob_req, &bytes_written);
                        clob_bytes += bytes_written;
                    }

                    if (lob_rc != 0)
                    {
                        if (text_is_heap) free((void *)resolved_text);
                        rc = -1;
                        driver->rowid_result_free(&rowid_result);
                        goto Cleanup;
                    }

                    lob_count++;
                }

                if (text_is_heap) free((void *)resolved_text);
            }
        }
    }

    driver->rowid_result_free(&rowid_result);

    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Batch updated: rows_updated=%d", rows_updated);

    /* ================================================================
     *  Stage 2 Audit - Write field-level audit rows for UPDATE
     *
     *  Now that the UPDATE has executed successfully, write one
     *  AUDIT_TRAIL row per (row × changed column).
     *  Columns where OLD_VALUE == NEW_VALUE produce no audit row.
     *
     *  old_values was captured before the UPDATE above.
     *  atr.new_values = uc->values (the UPDATE SET values).
     *
     *  The cycle-guard (audit_trail_in_progress) is checked inside
     *  audit_trail_insert_update() so no guard is needed here.
     * ================================================================ */
    if (!audit_trail_in_progress && rc == 0 && old_values)
    {
        logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                     "Calling audit_trail_insert_update for table='%s' "
                     "rows=%d cols=%d",
                     uc->table_name, uc->row_count, uc->col_count);

        audit_trail_request_t atr;
        memset(&atr, 0, sizeof(atr));

        strncpy(atr.table_name,  uc->table_name,
                sizeof(atr.table_name)  - 1);
        strncpy(atr.action_type, "UPDATE",
                sizeof(atr.action_type) - 1);
        strncpy(atr.changed_by,  ctx->ini->username,
                sizeof(atr.changed_by)  - 1);
        strncpy(atr.module_name, "OCI_Update_Execute",
                sizeof(atr.module_name) - 1);

        /* change_reason: use transaction name if available            */
        if (ctx->active_tx && ctx->active_tx->tx_name[0] &&
            strcmp(ctx->active_tx->tx_name, "-") != 0)
            strncpy(atr.change_reason, ctx->active_tx->tx_name,
                    sizeof(atr.change_reason) - 1);
        else
            strncpy(atr.change_reason, "Business UPDATE via Data_Manager",
                    sizeof(atr.change_reason) - 1);

        /* record_id: use first key value as the record identifier     */
        if (uc->key_count > 0)
            strncpy(atr.record_id, uc->keys[0].key_value,
                    sizeof(atr.record_id) - 1);
        else
            strncpy(atr.record_id, "-", sizeof(atr.record_id) - 1);

        atr.col_names  = uc->col_names;
        atr.col_types  = cols;
        atr.new_values = uc->values;    /* UPDATE SET values           */
        atr.old_values = NULL;          /* supplied via old_values arg */
        atr.col_count  = uc->col_count;
        atr.row_count  = uc->row_count;
        atr.audit_mode = AUDIT_MODE_FIELD;

        int audit_rc = audit_trail_insert_update(ctx, &atr, old_values);
        if (audit_rc != 0)
            logger_write(ctx->update_logger, LOG_WARN, __func__, 0,
                         "Audit trail UPDATE failed (rc=%d) for "
                         "table='%s' - business UPDATE is NOT rolled back.",
                         audit_rc, uc->table_name);
    }
    else if (!old_values && !audit_trail_in_progress && rc == 0)
    {
        logger_write(ctx->update_logger, LOG_WARN, __func__, 0,
                     "Skipping UPDATE audit - before-image unavailable "
                     "for table='%s'", uc->table_name);
    }

    /* ---- Commit (skipped when a managed transaction is active) ---- */
    /*
     * If ctx->active_tx is set, the caller (e.g. Test_XML_Runner) has
     * opened an explicit transaction via tx_begin().  In that case the
     * work inserted here must stay uncommitted so the caller can batch
     * it with other DML steps and commit or roll back the whole unit
     * atomically via tx_commit() / tx_rollback().
     *
     * If ctx->active_tx is NULL this module owns the commit, which is
     * the original standalone behaviour.
     *
     * Fixed 2026-09-23 (same data-loss bug as OCI_Insert_Execute_
     * Module.c - see its own copy of this comment for the full
     * explanation). owns_standalone_tx distinguishes "an outer caller
     * genuinely owns this transaction" from "I only have an
     * active_tx because I gave myself one for audit traceability".  */
    if (ctx->active_tx && !owns_standalone_tx)
    {
        logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                     "Commit successful rows_updated=%d lobs=%d",
                     rows_updated, lob_count);
    }
    else
    {
        /* ---- Commit ---- */
        logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                     "Calling driver commit");

        /* Stage 3 (2026-10-03): the retry loop is core's, not the
         * driver's - see tx_commit_with_retry(), Transaction_Manager.h. */
        if (tx_commit_with_retry(ctx, ctx->update_logger,
                                 ctx->ini ? ctx->ini->tx_max_retries    : 0,
                                 ctx->ini ? ctx->ini->tx_retry_delay_ms : 0,
                                 NULL) != 0)
        {
            logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                         "driver commit failed");
            rc = -1;
            goto Cleanup;
        }

        logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                     "Commit successful rows_updated=%d lobs=%d",
                     rows_updated, lob_count);
    }

    /* Table-level resultset cache invalidation (closure item 5
     * follow-up, 2026-08-12) - regression fix for UT-SEL-004. Same
     * "fires regardless of managed-tx vs auto-commit, erring toward
     * eager invalidation over any risk of stale reads" reasoning as
     * OCI_Insert_Execute_Module.c's own identical block - see that
     * one's own comment for the full explanation.                     */
    resultset_cache_invalidate_by_table(ctx->resultset_cache, req->table_name);



    /* ================================================================
     *  Stage 5 - Build result response
     *  Uses response_write_dml_xml()/response_write_dml_json() - same
     *  writers built for INSERT, reused unchanged here (that's the
     *  whole reason dml_response_t is one shared struct rather than
     *  three near-duplicates - see its own doc comment in
     *  OCI_Request_Response_Types.h).
     * ================================================================ */
    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Stage 5: Building result response");

    clock_gettime(CLOCK_MONOTONIC, &ts_end);
    double elapsed =
        (ts_end.tv_sec  - ts_start.tv_sec) +
        (ts_end.tv_nsec - ts_start.tv_nsec) / 1e9;

    dml_response_t resp;
    memset(&resp, 0, sizeof(resp));
    strncpy(resp.table_name, uc->table_name, sizeof(resp.table_name) - 1);
    strncpy(resp.owner,      uc->owner,      sizeof(resp.owner) - 1);
    resp.rows_affected          = rows_updated;
    resp.lobs_written           = lob_count;
    resp.execution_time_seconds = elapsed;

    char *dml_xml_fragment = response_write_dml_xml(ctx, OP_UPDATE, &resp);
    if (!dml_xml_fragment)
    {
        logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                     "response_write_dml_xml returned NULL");
        rc = -1;
        goto Cleanup;
    }

    xml = xml_create(4096);
    if (!xml) { free(dml_xml_fragment); rc = -1; goto Cleanup; }

    xml_start_document(xml);
    xml_start_execution(xml);
    /* xml_append_raw(), not xml_append(xml,"%s",...) - see the
     * 2026-07-22 fix in OCI_Execute_Query_Batch_Module.c for why:
     * the latter formats into a fixed 8192-byte stack buffer and
     * silently corrupts anything longer.                               */
    xml_append_raw(xml, dml_xml_fragment);
    xml_end_execution(xml);
    xml_finalize(xml);
    free(dml_xml_fragment);

    /* cfg->OUTPUT_JSON's own doc comment in OCI_Connection.h: "set
     * only when ReturnFormat is JSON. NULL otherwise."                  */
    if (cfg->ReturnFormat && strcasecmp(cfg->ReturnFormat, "JSON") == 0)
    {
        cfg->OUTPUT_JSON = response_write_dml_json(ctx, OP_UPDATE, &resp);
        if (!cfg->OUTPUT_JSON)
            logger_write(ctx->update_logger, LOG_ERROR, __func__, 0,
                         "response_write_dml_json returned NULL - "
                         "OUTPUT_JSON will be missing for this JSON-format request");
    }

    metrics.end_time_us      = metrics_now_us();
     metrics.status_code     = 0;
     strncpy(metrics.error_code, "-", sizeof(metrics.error_code) - 1);
     strncpy(metrics.error_text, "-", sizeof(metrics.error_text) - 1);
     metrics.rows_affected    = rows_updated;
     metrics.output_xml_bytes = xml ? (uint64_t)strlen(xml->buffer) : 0;
     metrics.lob_bytes        = lob_bytes;
     metrics.clob_bytes       = clob_bytes;
     /* transaction_id already set at init time */

    if (!cfg->xml) cfg->xml = calloc(1, sizeof(*cfg->xml));
    cfg->xml->OUTPUT_XML = strdup(xml->buffer);

    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "execute_update_batch complete: table='%s' "
                 "rows=%d elapsed=%.6f",
                 uc->table_name, rows_updated, elapsed);

Cleanup:
    /* Stage 6 - Cleanup */
    logger_write(ctx->update_logger, LOG_INFO, __func__, 0, "Stage 6: Cleanup");
    metrics.end_time_us = metrics_now_us();
    metrics.status_code = rc;

    if (rc != 0)
    {
	    strncpy(metrics.error_code,
	            logger_last_error.error_code,
	            sizeof(metrics.error_code) - 1);
	    strncpy(metrics.error_text,
	            logger_last_error.error_text,
	            sizeof(metrics.error_text) - 1);
    }
 	if(ctx->active_tx)
		strncpy(metrics.transaction_id , tx_get_id(ctx->active_tx),sizeof(metrics.transaction_id)-1);
	else
		strncpy(metrics.transaction_id , "-",sizeof(metrics.transaction_id)-1);
	strncpy(metrics.transaction_name , ctx->active_tx ? ctx->active_tx->tx_name : "-", sizeof(metrics.transaction_name)-1);
	metrics.connection_wait_us    = ctx->connection_wait_us;
	metrics.connection_create_us  = ctx->connection_create_us;
	metrics.connection_acquire_us = ctx->connection_acquire_us;

	//Process final 3 metrics
	if (ctx->ini && ctx->ini->metrics_display_input_file_name && cfg->input_file_name)
	    metrics.input_file_name = flatten_for_csv(cfg->input_file_name);

	if (ctx->ini && ctx->ini->metrics_display_input_request && ctx->INPUT_XML)
	    metrics.input_request = flatten_for_csv3(ctx->INPUT_XML);


	if (ctx->ini && ctx->ini->metrics_display_output_response)
	{
	    /* UPDATE doesn't render a JSON response yet (only the SELECT
	     * batch path does) - this is a no-op fallback to XML until it
	     * does, kept consistent with the other execute modules.       */
	    int is_json = (cfg->ReturnFormat &&
	                   strcasecmp(cfg->ReturnFormat, "JSON") == 0);

	    if (is_json && cfg->OUTPUT_JSON)
	        metrics.output_response = flatten_for_csv3(cfg->OUTPUT_JSON);
	    else if (cfg->xml && cfg->xml->OUTPUT_XML)
	        metrics.output_response = flatten_for_csv3(cfg->xml->OUTPUT_XML);
	}





	metrics_finalise_and_enqueue(ctx->metrics_writer, ctx->metrics_writer_logger, &metrics);
    logger_clear_last_error();   // reset for next operation



    if (rc != 0 && rows_updated > 0)
    {
        logger_write(ctx->update_logger, LOG_WARN, __func__, 0,
                     "Rolling back due to error");
        driver->rollback(ctx, ctx->update_logger);
    }

    free(bind_values);
    for (int t = 0; t < text_heap_count; t++) free(text_heap[t]);
    free(text_heap);

    if (old_values) { free(old_values); old_values = NULL; }

    if (uc)
    {
        if (uc->values) free_update_ctx_values(uc->values, uc->col_count);
        free(uc);
    }

    if (xml)  { xml_free(xml); }

    logger_write(ctx->update_logger, LOG_INFO, __func__, 0,
                 "Cleanup complete rc=%d", rc);

    end_standalone_tx_if_owned(ctx, owns_standalone_tx);

    return rc;
}
